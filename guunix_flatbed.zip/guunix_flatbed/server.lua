QBCore = exports['qb-core']:GetCoreObject()

RegisterNetEvent("guunix_flatbed:log")
AddEventHandler("guunix_flatbed:log", function(action, vehiclePlate)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if Player then
        print(("[FLATBED LOG] %s (%s) realizó: %s | Vehículo: %s"):format(
            Player.PlayerData.name,
            Player.PlayerData.citizenid,
            action,
            vehiclePlate or "N/A"
        ))
    end
end)
