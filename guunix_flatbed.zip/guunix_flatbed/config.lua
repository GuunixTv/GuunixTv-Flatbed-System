Config = {}

-- Trabajo autorizado para usar la grúa
Config.JobRequired = "mechanic"

-- Vehículos permitidos (puedes agregar más modelos si quieres limitar)
-- Si quieres permitir todos, deja la tabla vacía: {}
Config.AllowedVehicles = {}

-- Modelo del vehículo grúa
Config.FlatbedModel = "flatbed"

-- Posición personalizada donde se coloca el vehículo encima de la grúa
Config.AttachPosition = {
    x = 0.0,       -- centrado en el medio de la plataforma
    y = -5.45,     -- hacia la parte trasera de la plataforma
    z = 1.00       -- altura perfecta justo sobre la plataforma
}
