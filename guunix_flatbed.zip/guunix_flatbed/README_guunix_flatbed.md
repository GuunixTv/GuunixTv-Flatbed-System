
# 🚛 Guunix Flatbed Tow Script

**Author:** GuunixTv  
**Framework:** Standalone (Compatible with QBCore & ESX)  
**Version:** 1.0.0  

---

## 📦 Description

The **Guunix Flatbed Tow Script** allows players to tow vehicles using a flatbed truck in a smooth and realistic way.  
This script is fully standalone, lightweight, and easy to integrate with any framework or job system.

---

## 🔧 Features

- ✅ Standalone – No dependency on QBCore or ESX
- ✅ Smooth attach/detach animations
- ✅ Compatible with all flatbed vehicles
- ✅ Very low performance usage (idle: ~0.00ms)
- ✅ Easy to configure via `config.lua`
- ✅ Command-based interaction or easy to integrate into job menu

---

## 🚀 Installation

1. Extract the folder `guunix_flatbed` into your server's `resources/` directory.
2. Add the following line to your `server.cfg`:
   ```
   ensure guunix_flatbed
   ```
3. Restart your server.

---

## 🎮 Usage

- Use the command `/flatbed` near a vehicle with a flatbed to attach or detach.
- Recommended vehicle model: `flatbed`, `flatbed3`, or any custom tow truck.

---

## 🖼️ Showcase

*Insert your screenshot or video here.*

---

## 📁 Support & Custom Work

Created by **GuunixTv**.  
For help or custom versions, contact via Discord or Cfx PMs.

---
