fx_version 'cerulean'
lua54 'yes'
game 'gta5'

description 'Guunix Flatbed Tow Script'
author 'Guunix Scripts'
version '1.0.0'

client_scripts {
    'config.lua',
    'client.lua'
}

server_script 'server.lua'

shared_script '@ox_lib/init.lua'
