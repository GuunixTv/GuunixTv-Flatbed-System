
local QBCore = exports['qb-core']:GetCoreObject()
local towingVehicle = nil
local towedVehicle = nil
local lastAdjustedPosition = nil

function SubirVehiculoDesdeDentro()
    local playerPed = PlayerPedId()

    if IsPedInAnyVehicle(playerPed, false) then
        local veh = GetVehiclePedIsIn(playerPed, false)
        local coords = GetEntityCoords(playerPed)
        local flatbed = GetClosestVehicle(coords, 10.0, 0, 70)

        if flatbed and DoesEntityExist(flatbed) and GetEntityModel(flatbed) == GetHashKey(Config.FlatbedModel) then
            local model = GetEntityModel(veh)
            if #Config.AllowedVehicles == 0 or IsModelAllowed(model) then
                SetEntityHeading(veh, GetEntityHeading(flatbed))
                TaskLeaveVehicle(playerPed, veh, 0)
                Wait(1000)

                SetVehicleEngineOn(veh, false, true, true)
                SetVehicleHandbrake(veh, true)
                FreezeEntityPosition(veh, true)
                SetEntityCollision(veh, false, false)

                AttachEntityToEntity(
                    veh,
                    flatbed,
                    20,
                    Config.AttachPosition.x or 0.0,
                    Config.AttachPosition.y or -1.45,
                    Config.AttachPosition.z or 1.05,
                    0.0, 0.0, 0.0,
                    false, false, true, false, 2, true
                )

                Wait(100)
                FreezeEntityPosition(veh, true)

                towedVehicle = veh
                towingVehicle = flatbed
                QBCore.Functions.Notify("Vehículo fijado a la plataforma", "success")
                TriggerServerEvent("guunix_flatbed:log", "Subió vehículo desde dentro", GetVehicleNumberPlateText(veh))
            else
                QBCore.Functions.Notify("Este modelo de vehículo no puede ser remolcado", "error")
            end
        else
            QBCore.Functions.Notify("No hay grúa cerca o no es una flatbed", "error")
        end
    else
        QBCore.Functions.Notify("Debes estar dentro del vehículo que quieres remolcar", "error")
    end
end

function BajarVehiculo()
    local playerPed = PlayerPedId()
    local coords = GetEntityCoords(playerPed)
    local flatbed = GetVehiclePedIsIn(playerPed, true)

    if not DoesEntityExist(flatbed) or GetEntityModel(flatbed) ~= GetHashKey(Config.FlatbedModel) then
        flatbed = GetClosestVehicle(coords, 10.0, 0, 70)
    end

    if not DoesEntityExist(flatbed) then
        QBCore.Functions.Notify("No hay grúa cerca", "error")
        return
    end

    local vehs = GetGamePool("CVehicle")
    for _, veh in pairs(vehs) do
        if IsEntityAttachedToEntity(veh, flatbed) then
            DetachEntity(veh, true, true)
            Wait(100)
            FreezeEntityPosition(veh, false)
            SetVehicleHandbrake(veh, false)
            SetVehicleEngineOn(veh, true, true, false)
            SetEntityCollision(veh, true, true)
            SetVehicleOnGroundProperly(veh)
            SetEntityVelocity(veh, 0.0, 0.0, 0.0)

            local dropOffset = GetOffsetFromEntityInWorldCoords(flatbed, 0.0, -7.0, -0.5)
            SetEntityCoords(veh, dropOffset.x, dropOffset.y, dropOffset.z, false, false, false, true)

            QBCore.Functions.Notify("Vehículo bajado correctamente", "success")
            TriggerServerEvent("guunix_flatbed:log", "Bajó vehículo", GetVehicleNumberPlateText(veh))
            return
        end
    end

    QBCore.Functions.Notify("No hay vehículo remolcado", "error")
end

function IsModelAllowed(model)
    for _, allowed in pairs(Config.AllowedVehicles) do
        if model == GetHashKey(allowed) then
            return true
        end
    end
    return false
end

RegisterCommand("flatbed", function()
    TriggerEvent("guunix_flatbed:menu")
end)

RegisterCommand("ajustarvehiculo", function()
    local playerPed = PlayerPedId()
    if not IsPedInAnyVehicle(playerPed, false) then
        QBCore.Functions.Notify("Debes estar dentro del vehículo que deseas montar", "error")
        return
    end

    local veh = GetVehiclePedIsIn(playerPed, false)
    local flatbed = GetClosestVehicle(GetEntityCoords(playerPed), 10.0, 0, 70)
    if not DoesEntityExist(flatbed) or GetEntityModel(flatbed) ~= GetHashKey(Config.FlatbedModel) then
        QBCore.Functions.Notify("No hay una grúa flatbed cerca", "error")
        return
    end

    TaskLeaveVehicle(playerPed, veh, 0)
    Wait(1000)

    local adjusting = true
    local data = { x = 0.0, y = -1.45, z = 1.05 }

    FreezeEntityPosition(veh, true)
    SetEntityCollision(veh, false, false)

    CreateThread(function()
        lib.showTextUI(
            "[↑↓←→] Mover | [PgUp/PgDn] Altura | [ENTER] Confirmar | [BACKSPACE] Cancelar",
            { position = "top-center", style = { backgroundColor = '#111', color = '#fff', fontSize = '18px' } }
        )

        while adjusting do
            if IsControlJustPressed(0, 172) then data.y = data.y + 0.05 end
            if IsControlJustPressed(0, 173) then data.y = data.y - 0.05 end
            if IsControlJustPressed(0, 174) then data.x = data.x - 0.05 end
            if IsControlJustPressed(0, 175) then data.x = data.x + 0.05 end
            if IsControlJustPressed(0, 10) then data.z = data.z + 0.02 end
            if IsControlJustPressed(0, 11) then data.z = data.z - 0.02 end

            AttachEntityToEntity(veh, flatbed, 20, data.x, data.y, data.z, 0.0, 0.0, 0.0, false, true, false, false, 2, true)

            local markerPos = GetOffsetFromEntityInWorldCoords(veh, 0.0, 0.0, 1.2)
            DrawMarker(0, markerPos.x, markerPos.y, markerPos.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 50, 255, 50, 180, false, true, 2, false, nil, nil, false)

            if IsControlJustPressed(0, 191) then
                FreezeEntityPosition(veh, true)
                SetEntityCollision(veh, true, true)
                SetVehicleOnGroundProperly(veh)
                lastAdjustedPosition = vector3(data.x, data.y, data.z)
                lib.hideTextUI()
                QBCore.Functions.Notify(string.format("Posición guardada: x=%.2f y=%.2f z=%.2f", data.x, data.y, data.z), "success")
                adjusting = false
            end

            if IsControlJustPressed(0, 194) then
                DetachEntity(veh, true, true)
                FreezeEntityPosition(veh, false)
                SetEntityCollision(veh, true, true)
                lib.hideTextUI()
                QBCore.Functions.Notify("Ajuste cancelado", "error")
                adjusting = false
            end

            Wait(0)
        end
    end)
end)

RegisterNetEvent('guunix_flatbed:menu', function()
    QBCore.Functions.GetPlayerData(function(PlayerData)
        if PlayerData.job.name ~= Config.JobRequired then
            QBCore.Functions.Notify("No tienes permiso para usar la grúa", "error")
            return
        end

        lib.registerContext({
            id = 'flatbed_menu',
            title = 'Menú de Grúa',
            options = {
                {
                    title = '🔧 Ajustar posición del vehículo',
                    icon = 'ruler',
                    onSelect = function()
                        ExecuteCommand("ajustarvehiculo")
                    end
                },
                {
                    title = '🚚 Subir este vehículo a la plataforma',
                    icon = 'truck-ramp-box',
                    onSelect = function()
                        Config.AttachPosition = {
                            x = lastAdjustedPosition and lastAdjustedPosition.x or Config.AttachPosition.x,
                            y = lastAdjustedPosition and lastAdjustedPosition.y or Config.AttachPosition.y,
                            z = lastAdjustedPosition and lastAdjustedPosition.z or Config.AttachPosition.z
                        }
                        SubirVehiculoDesdeDentro()
                    end
                },
                {
                    title = '⬇️ Bajar vehículo de la plataforma',
                    icon = 'car',
                    onSelect = function()
                        BajarVehiculo()
                    end
                }
            }
        })

        lib.showContext('flatbed_menu')
    end)
end)
